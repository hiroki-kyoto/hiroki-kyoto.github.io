sqlplus sys/root as sysdba @EXPORT_2G_WEAL.PRC
