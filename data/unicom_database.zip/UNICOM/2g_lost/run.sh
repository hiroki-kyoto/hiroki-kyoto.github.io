sqlplus sys/root as sysdba @P_DYL_2G_LOST_FLAG_ANSI.prc
sqlplus sys/root as sysdba @P_DYL_2G_LOST_FLAG_WEAL_ANSI.prc
sqlplus sys/root as sysdba @P_DYL_2G_LOST_FLAG_END_ANSI.prc
sqlplus sys/root as sysdba @P_DYL_2G_LOST_FLAG_END2_ANSI.prc
sqlplus sys/root as sysdba @TEST.prc
